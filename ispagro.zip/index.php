<!DOCTYPE html>
<html>


<head>
    <meta charset="utf-8">
    <title>ispAgro Robotics Pvt Ltd &#8211; Bangalore, India</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <link href="css/font-awesome.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet" media="all">

    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

    <script src="js/modernizr.js"></script>

    <link rel="stylesheet" href="css/flexslider.css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.flexslider.js"></script>
    <script type="text/javascript">
        $(window).load(function() {
            $('.flexslider').flexslider({
                animation: "slide",
                useCSS: Modernizr.touch
            });
        });

    </script>

</head>

<body>

    <?php include'includes/header.php'?>

    <div class="jumbotron masthead">
        <div class="container">

            <div class="flexslider">
                <ul class="slides">
                    <li>
                        <div class="hero-unit">
                            <h1>Robotics inspired by nature.</h1>
                            <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h3>
                        </div>
                    </li>
                    <li>
                        <div class="slide2">
                            <p><img src="images/robotics1.png" alt="robotics" class="img-responsive center-block" width="50%"></p>
                            <h1>Robotics inspired by nature.</h1>
                        </div>
                    </li>
                    <li>
                        <div class="slide3">
                            <p class="pull-left"><img src="images/robotics2.png" alt="robotics" class="img-responsive"></p>
                            <h1>Robotics inspired by nature.</h1>
                            <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h3>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row PageHead">
            <div class="col-md-12">
                <h1>Why Us</h1>
                <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
            </div>
            <div class="col-md-12 PageHead">
                <div class="row">
                    <div class="col-md-6"><img src="images/why-us.jpg" alt="why us" width="100%" height="100%"></div>
                    <div class="col-md-6">
                        <p>Drones or Unmanned Aerial Vehicles (UAVs) are the futuristic solutions. Most of the current applications are based prominently on piloted observations. We here at iSpAgro Robotics, aspire to explore various horizons with cutting edge technology. And also take client’s requirements and forge them into solutions.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mainFeatures" id="features">
            <div class="col-sm-6 col-md-4">
                <div class="img-thumbnail"> <img src="images/secure_img.png" width="85" height="88" alt="secure">
                    <div class="caption">
                        <h4>Lorem Ipsum</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="img-thumbnail"> <img src="images/fast_img.png" width="85" height="88" alt="secure">
                    <div class="caption">
                        <h4>Lorem Ipsum</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-0">
                <div class="img-thumbnail"> <img src="images/support_img.png" width="85" height="88" alt="secure">
                    <div class="caption">
                        <h4>Lorem Ipsum</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row PageHead">
            <div class="col-md-12">
                <h1>Industries</h1>
                <h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 features"> <img src="images/constr.png" alt="icon" class="img-responsive">
                <h4>Construction</h4>
                <p>"Perfect solution to paint and clean skyscrapers”</p>
            </div>
            <div class="col-sm-6 features"> <img src="images/defence.png" alt="icon" class="img-responsive">
                <h4>Defense</h4>
                <p>"The solutions to take control over the potential threat depend on the risk scenario, the perimeter to protect and the forces in charge.”</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 features"> <img src="images/serve.png" alt="icon" class="img-responsive">
                <h4>Surveillance</h4>
                <p>"GIS, photogrammetry and sensors used to give detailed topological and geographic data. Also get a bird's-eye view cataloging of events"</p>
            </div>
            <div class="col-sm-6 features"> <img src="images/agri.png" alt="icon" class="img-responsive">
                <h4>Agriculture</h4>
                <p>"Technological solution for data collection, analytics and automation in farming activity”</p>
            </div>
        </div>
    </div>

    <?php include'includes/footer.php'?>
    
</body>

</html>
