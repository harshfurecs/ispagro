<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Training &#8211; ispAgro Robotics Pvt Ltd</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <link href="css/font-awesome.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

    <script src="js/modernizr.js"></script>

    <script src="js/jquery.min.js"></script>
</head>

<body>

   <?php include'includes/header.php'?>
 

    <div class="container">

        <div class="row PageHead" id="pricing">
            <div class="col-md-12" style="background-color: #f109098c">
                <h1>ISPAGRO ROBOTICS collaboration with  MIT-MAHE</h1><br/>
                <div class="col-sm-6 col-md-6">
                    <img src="images/logo.png" width="40%" height="100%">
                </div>
                <div class="col-sm-6 col-md-6">
                    <img src="images/21.jpg" width="100%" height="100%">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-6 PlanPricing">
                <div class="planName"> <span class="price"><i class="fa fa-rupee"></i> 25,500</span>
                    <h3>Drone Photogarphy Training</h3>
                    <p>3 Days</p>
                </div>
                <div class="planFeatures">
                    <ul>
                        <li>Introduction</li>
                        <li>Rules and Regulations</li>
                        <li>Key Drone Handling and Impact on Production</li>
                        <li>Pre-Flight Planning & Flight Day Management</li>
                        <li>Principles to Get Great Footage & Edit Footage Towards Final Production</li>
                        <li>Handling and Maintenance</li>
                        <li>Flying Drones with Simulators and Real Time Flight.</li>
                        <li>Result Analysis Towards Final Production</li>
                    </ul>
                </div>
                <p> <a href="#" role="button" class="btn btn-success btn-lg">Register Now</a> </p>
            </div>
            <div class="col-sm-6 col-md-6 PlanPricing">
                <div class="planName"> <span class="price"><i class="fa fa-rupee"></i> 32,500</span>
                    <h3>Advanced Drone Training</h3>
                    <p>5 Days</p>
                </div>
                <div class="planFeatures">
                    <ul>
                        <li>Introduction</li>
                        <li>Rules and Regulations</li>
                        <li>Basic Radio Telephony (RT) technique including radio frequency.</li>
                        <li>Basic Knowledge of principles of Flight and Aerodynamics for Fixed Wings, Rotary Wings.</li>
                        <li>Flight Planning and ATC Procedure</li>
                        <li>Tutorial to Build your own UAV</li>
                        <li>Handling & maintenance and applications</li>
                        <li>Flight simulator & Real Time Flight</li>
                        <li>Result Analysis</li>
                    </ul>
                </div>
                <p> <a href="#" role="button" class="btn btn-success btn-lg">Register Now </a> </p>
            </div>
        </div>
    </div>

   <?php include'includes/footer.php'?>
</body>


</html>
