  <nav class="navbar navbar-default navbar-fixed-top" role="navigation">

      <div class="container">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
              <a class="navbar-brand" href="index.php"> <img src="images/logo.png" alt="logo"></a> </div>

          <div class="collapse navbar-collapse navbar-ex1-collapse">
              <ul class="nav navbar-nav navbar-right">
                  <li class="active <?php echo''?>"><a href="index.php">HOME</a></li>
                  <li class="hidden-sm"><a href="about.php">About</a></li>
                  <li class="hidden-sm"><a href="products.php">Products</a></li>
                  <li><a href="">Join Us</a></li>
                  <!--
                    <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">BLOG <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="blog.html">Blog List</a></li>
                            <li><a href="blog-post.html">Single Blog page</a></li>
                        </ul>
                    </li>
-->
                  <li><a href="training.php">Training</a></li>
                  <li><a href="contact.php">CONTACT us</a></li>
                  <!--
                    <li><a href="#" role="button" data-toggle="modal" data-target="#Login">Login</a></li>
                    <li><a href="whmcs/register.html" role="button" class="btn btn-success">Sign Up</a></li>
-->
              </ul>
              </li>
              </ul>
          </div>

      </div>
  </nav>
