<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Products &#8211; ispAgro Robotics Pvt Ltd</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <link href="css/font-awesome.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet" media="all">

    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

    <script src="js/modernizr.js"></script>

    <script src="js/jquery.min.js"></script>

</head>

<body>

    <?php include'includes/header.php'?>

    <div class="container">
        <div class="row PageHead">
            <h1>Products</h1>
            <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            <ul class="tabs clearfix" data-tabgroup="first-tab-group">
                <li><a href="#tab1" class="active">HBQ</a></li>
                <li><a href="#tab2">SEED BOMBING</a></li>
                <li><a href="#tab3">PAINTING DRONE</a></li>
                <li><a href="#tab4">SURVEILLANCE DRONE</a></li>
            </ul>
            <section id="first-tab-group" class="tabgroup">
                <div id="tab1">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6"><iframe width="560" height="315" src="https://www.youtube.com/embed/HYSlPWTyX_c" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
                            <div class="col-md-6">
                                <h2>HBQ</h2>
                                <ul class="ticklist">
                                    <li>POWER TETHER</li>
                                    <li>AUTO CLAMPING & DECLAMPING</li>
                                    <li>AUTO PRECISSION SPRAY</li>
                                    <li>LIVE VIDEO FEED</li>
                                    <li>IMAGE RECOGNITION</li>
                                    <li>CONTROL VIA MOBILE APP</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tab2">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6"><iframe width="560" height="315" src="https://www.youtube.com/embed/LOFEjxge1n4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
                            <div class="col-md-6">
                                <h2>SEED BOMBING</h2>
                                <ul class="ticklist">
                                    <li>6KG PAY LOAD</li>
                                    <li>AUTONOMOUS OPERATION</li>
                                    <li>AUTO SEED BOBMBING</li>
                                    <li>LIVE VIDEO FEED</li>
                                    <li>1 ACRE IN 10MIN</li>
                                    <li>POST SEEDING PROGRESS ASSESSMENT</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tab3">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6"><iframe width="560" height="315" src="https://www.youtube.com/embed/fbsGUxGdyhg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
                            <div class="col-md-6">
                                <h2>PAINTING DRONE</h2>
                                <ul class="ticklist">
                                    <li>AIRLESS PAINTING</li>
                                    <li>AUTONOMOUS OPERATION</li>
                                    <li>POWER TETHER</li>
                                    <li>0.5 – 2 LPM PAINT FLOW RATE</li>
                                    <li>15-100 SQFT/MIN SPRAY COVERAGE </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tab4">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6"><iframe width="560" height="315" src="https://www.youtube.com/embed/mXQUAM1qK5g" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
                            <div class="col-md-6">
                                <h2>SURVEILLANCE DRONE</h2>
                                <ul class="ticklist">
                                    <li>FLIGHT TIME 4-8hrs</li>
                                    <li>REDUNDANT BATTERY</li>
                                    <li>POWER FAILSAFE</li>
                                    <li>LIVE SYSTEM LIFE MONITORING</li>
                                    <li>TETHER SUPPORT AND SAFTY</li>
                                    <li>100FT HEIGHT</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php include'includes/footer.php'?>
</body>


</html>
