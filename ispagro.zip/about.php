<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>About &#8211; ispAgro Robotics Pvt Ltd</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <link href="css/font-awesome.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet" media="all">

    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

    <script src="js/modernizr.js"></script>

    <script src="js/jquery.min.js"></script>

</head>

<body>

    <?php include'includes/header.php'?>
    <div class="container">

        <div class="row FeatLayout">
            <div class="col-md-5 Featimg"> <img src="images/company-bg.jpg" alt="feature" class="img-responsive center-block"></div>
            <div class="col-md-7">
                <h1>About The Company</h1>
                <p class="text-justify">iSPAGRO Robotics is a start-up working towards engineering solutions to prevailing problems with an innovative approach. We are currently developing drones for addressing problems in the agricultural industry, with unique and original designs that could be applied to other sectors as well such as defence, inspection and maintenance, firefighting etc. For more information on the applications of our technology in other sectors, please see the industries section. P2G, the company brand name which stands for Prithvi to Gagan (Earth to Sky) aspires to address any sort of engineering problem across all industries, agriculture and beyond.</p>
                
            </div>
        </div>
        
        <div class="row FeatLayout">
            <div class="col-md-7">
                <h1>About The Team</h1>
                <p class="text-justify">The company was founded by agriculturists who have a clear understanding of the challenges and threats in the field. They have worked with the problem for more than 10 years with Automation industry experience in Rapid Prototyping, Scaling, and Product Development Life Cycle. The team currently has 5 highly motivated engineers with over 4 years of UAV flying experience, and we are constantly looking for dedicated and experienced individuals with an innovative mind. Please see the careers section if you would like to work with us.</p>
                
            </div>
            <div class="col-md-5 Featimg"> <img src="images/team-bg.jpg" alt="feature" class="img-responsive center-block"></div>
        </div>

    </div>


  <?php include'includes/footer.php'?>
</body>


</html>
