<!DOCTYPE html>
<html>

< <head>
    <meta charset="utf-8">
    <title>Contact &#8211; ispAgro Robotics Pvt Ltd</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <link href="css/font-awesome.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

    <script src="js/modernizr.js"></script>

    <script src="js/jquery.min.js"></script>

    <script src="js/contact_form.js"></script>
    </head>

    <body>

        
    <?php include'includes/header.php'?>
        
        <div class="container" id="contact">
            <div class="row PageHead">
                <div class="col-md-12">
                    <h1>Contact Us</h1>
                    <h3>Keep in touch with us. we are here to help you</h3>
                </div>
            </div>
            <div class="row ContactUs">
                <div class="col-md-6">
                    <div class="row contact-left">
                        <div class="col-sm-4 text-center">
                            <i class="fa fa-home"></i>
                            <p>Peenya, Bengaluru, IN 560058</p>
                        </div>
                        <div class="col-sm-4 text-center">
                             <i class="fa fa-mobile"></i>
                            <p>(+91)-7349543275</p>
                        </div>
                        <div class="col-sm-4 text-center">
                             <i class="fa fa-envelope"></i>
                            <p>info@ispagro.in</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mapwrap">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15548.556444558142!2d77.512115!3d13.026812!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa8a6883e395c18f2!2siSpAgro+Robotics+Pvt.+Ltd.!5e0!3m2!1sen!2sus!4v1555330486632!5m2!1sen!2sus" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <form class="form" id="phpcontactform">
                        <div class="form-group">
                            <input class="form-control" type="text" placeholder="Full Name" name="name" id="name">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="email" placeholder="Email ID" name="email" id="email">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="text" placeholder="Mobile Number" name="mobile" id="mobile">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" rows="10" name="message" placeholder="Your Message" id="message"></textarea>
                        </div>
                        <div class="form-group">
                            <p>
                                <input class="btn btn-success btn-lg" type="submit" value="Send Message" />
                            </p>
                            <span class="loading"></span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
    <?php include'includes/footer.php'?>
    </body>


</html>
