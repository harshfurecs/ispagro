<div class="footer">
    <div class="container">
        <div class="row footerlinks">
            <div class="col-sm-12 col-md-4">
                <h3>IspAgro Robotics Pvt. Ltd.</h3>
                <p>Site #5, Plot #35, 1st Main Road, <br />80 feet road, Peenya Industrial Estate, Near NTTF, <br /> Bengaluru, Karnataka 560058 <br /> Call: +917349543275</p>
            </div>
            <div class="col-sm-12 col-md-4 text-center">
                <h3>Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="">Join Us</a></li>
                    <li><a href="training.php">Training</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li> <a href="https://www.instamojo.com/@ispagro/" target="_blank" class="btn btn-danger btn-small">Payment </a> </li>
                </ul>
            </div>
            <div class="col-sm-12 col-md-4 text-center">
                <h3>Social Media</h3>
                <ul class="social-network social-circle">
                    <li><a href="https://www.facebook.com/ISpAgro-Robotics-366212440539511/?ref=br_rs" target="_blank" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/ispagro" target="_blank" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.youtube.com/channel/UCyCZQK5z3bQKYwN99w89ziA" target="_blank" class="icoGoogle" title="Youtube"><i class="fa fa-youtube"></i></a></li>
                    <li><a href="https://in.linkedin.com/company/ispagro-robotics" target="_blank" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <br />
                <ul class="text-center">
                    
                </ul>
            </div>
        </div>
        <div class="row copyright">
            <p>Copyright &copy; 2019. ispAgro Robotics Pvt Ltd</p>
        </div>
    </div>
</div>

<script src="js/bootstrap.min.js"></script>
<script>
    $('.tabgroup > div').hide();
    $('.tabgroup > div:first-of-type').show();
    $('.tabs a').click(function(e) {
        e.preventDefault();
        var $this = $(this),
            tabgroup = '#' + $this.parents('.tabs').data('tabgroup'),
            others = $this.closest('li').siblings().children('a'),
            target = $this.attr('href');
        others.removeClass('active');
        $this.addClass('active');
        $(tabgroup).children('div').hide();
        $(target).show();

    })

</script>
